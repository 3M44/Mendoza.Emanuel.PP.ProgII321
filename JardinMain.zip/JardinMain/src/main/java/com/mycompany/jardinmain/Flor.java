package com.mycompany.jardinmain;

public class Flor extends Planta{
    private TemporadaFlorecimiento florecimiento;

    public Flor(TemporadaFlorecimiento florecimiento, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.florecimiento = florecimiento;
    }
    
    @Override
    public String especificacion(){
        return ", florece: " + florecimiento;
    }

    @Override
    public String sePuedePodar(){
        return " no se puede podar ya que es una flor";
    }
}

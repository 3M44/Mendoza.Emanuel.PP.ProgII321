package com.mycompany.jardinmain;


public enum TemporadaFlorecimiento {
    PRIMAVERA,
    VERANO,
    OTOÑO,
    INVIERNO;
}

package com.mycompany.jardinmain;


public class Arbusto extends Planta{
    private int densidad;

    public Arbusto(int densidad, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.densidad = densidad;
    }

   
    
    public String especificacion(){
        return ", densidad del follaje: " + densidad;
    }

    @Override
    public String sePuedePodar() {
        return " se pudo podar ya que es un arbusto";
    }
}

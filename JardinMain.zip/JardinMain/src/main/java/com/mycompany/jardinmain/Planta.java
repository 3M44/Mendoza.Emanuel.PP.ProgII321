package com.mycompany.jardinmain;


public abstract class Planta implements Podar{
    protected String nombre;
    protected String ubicacion;
    protected String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }
    
    @Override
    public boolean equals(Object o){
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        Planta other = (Planta) o;
        return other.nombre.equals(nombre) && other.ubicacion.equals(ubicacion);
    }

    @Override
    public String toString() {
        return "Planta{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", clima=" + clima + especificacion() + '}';
    }
    
    protected abstract String especificacion();
    
    public String podar(){
        return "El " + nombre + sePuedePodar();
    }
    
    protected abstract String sePuedePodar(); 
    
    
    
}

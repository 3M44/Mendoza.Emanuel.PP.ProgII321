package com.mycompany.jardinmain;

public interface Podar {
    
    public String podar();
}

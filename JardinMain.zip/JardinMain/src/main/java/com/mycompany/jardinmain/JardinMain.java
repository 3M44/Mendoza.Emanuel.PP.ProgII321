package com.mycompany.jardinmain;


public class JardinMain {

    public static void main(String[] args) {
        JardinBotanico j = new JardinBotanico();
        
        Planta p1 = new Arbol(10, "Roble", "Patio", "Soleado");
        Planta p2 = new Arbol(10, "Roble", "Patio", "Soleado");
        Planta p3 = new Flor(TemporadaFlorecimiento.OTOÑO, "Margarita", "Patio", "Soleado");
        Planta p4 = new Arbusto(18, "Bayas", "Patio", "Soleado");
        Planta p5 = new Arbusto(20, "Moras", "Patio", "Soleado");
       
        try {
        j.agregarPlanta(p1);
        j.agregarPlanta(p3);
        j.agregarPlanta(p4);
        j.agregarPlanta(p5);
         j.agregarPlanta(p2);
        }
        catch(PlantaRepetidaException p){
            System.out.println(p);
        }
        System.out.println("--------------------");
        j.mostrarPlantas();
        System.out.println("--------------------");
        
        
        j.podarPlantas();
    }
}
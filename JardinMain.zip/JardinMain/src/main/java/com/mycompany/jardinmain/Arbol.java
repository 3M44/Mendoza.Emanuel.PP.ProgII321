package com.mycompany.jardinmain;


public class Arbol extends Planta{
    private int altura;

    public Arbol(int altura, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.altura = altura;
    }
    
    @Override
    public String especificacion(){
        return ", altura: " + altura;
    }

    @Override
    public String sePuedePodar() {
        return " se pudo podar ya que es un arbol";
    }
    
    }

    
    
    
